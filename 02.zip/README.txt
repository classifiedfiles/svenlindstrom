SVEN LINDSTRÖM — SITE STRUCTURÉ

Point d'entrée :
- index.html

Pages :
- about.html
- story.html
- links.html
- rules.html

Styles :
- css/reset.css
- css/variables.css
- css/layout.css
- css/components.css
- css/pages.css

Scripts :
- js/main.js
- js/navigation.js

Données :
- data/character.json

Images :
- assets/images/home/
- assets/images/story/
- assets/images/military/
- assets/images/archive/

Pour héberger :
1. Décompresser le ZIP.
2. Envoyer tout le dossier tel quel sur l'hébergement.
3. Le serveur doit servir index.html à la racine.
4. Ne pas renommer les dossiers sans mettre à jour les chemins dans les fichiers HTML.

Le site est volontairement simple et statique afin d'être facile à héberger sur
GitHub Pages, Netlify, Cloudflare Pages ou n'importe quel hébergement web classique.
